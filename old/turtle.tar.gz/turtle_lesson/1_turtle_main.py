# ---importing libraries in python---
import turtle 
import time

# initialize screen (s)
s = turtle.Screen()
s.setup(width=1.0, height=1.0, startx=10, starty=0)
s.bgcolor("#d3d3d3")

# ---initialize turtle---  
turtle1 = turtle.Turtle(shape="turtle", visible=False)
turtle1.shapesize(4,4,4)
turtle1.color("#006400")

turtle1.penup()
turtle1.goto(-s.window_width()/2,0)
turtle1.pendown()

# ---Introduction--- 
turtle1.showturtle()
turtle1.speed(1) 
turtle1.goto(0,0)
turtle1.left(90)

# title of presentation 
text = turtle.Turtle()
text.ht()
text.penup()
text.goto(0,100)
text.write("Teaching Python with Turtle!", align="center", font=("Arial",24,"bold"))

time.sleep(5) 

# move turtle to section 1 
turtle1.forward(180)
turtle1.right(90)
turtle1.forward(150)

# section 1
text.left(90)
text.forward(150)
text.right(90)
text.forward(240)

text.write("* Python's implementation of LOGO (1967)", align="left", font=("Arial",15))   
text.right(90)
text.forward(50)
text.write("* Learning children how to program", align="left", font=("Arial",15))
text.forward(50)
text.write("* Basis for Graphical User Interfaces (GUI's)", align="left", font=("Arial",15))
text.forward(50)
text.write("* Visual learners (Howard Gardner)", align="left", font=("Arial",15))

time.sleep(180)

# move turtle to section 2
turtle1.forward(300)
turtle1.right(90)
turtle1.forward(300)
turtle1.right(90)
turtle1.forward(500)

# move text to section 2    
text.forward(150)
text.right(90)
text.forward(800)
text.left(90)

text.write("Goals: ", align="left", font=("Arial",15,"bold"))
text.forward(50)
text.write("* Demonstrate the educational value of turtle", align="left", font=("Arial",15))
text.forward(50)
text.write("* Apply it to for-loops, while-loops and functions", align="left", font=("Arial",15))
text.forward(50)
text.write("* Project: squaring the circle", align="left", font=("Arial",15))

time.sleep(120) 
turtle1.forward(1000) 

s.exitonclick()

