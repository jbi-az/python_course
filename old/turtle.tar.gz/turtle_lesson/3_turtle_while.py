import turtle
from random import randint

# initialize screen (s)
s = turtle.Screen()
s.setup(width=1.0, height=1.0, startx=10, starty=0)
s.bgcolor("#d3d3d3")

# title 
text = turtle.Turtle()
text.penup()
text.hideturtle()
text.goto(0,250)
text.write("Wandering turtle (while-loop)", align="center", font=("Arial",24,"bold")) 

# bounding box 
box = turtle.Turtle(visible=False)
box.speed(0)
box.penup()
box.goto(-200,200)
box.pendown()

for i in range(4):
    box.forward(400)
    box.right(90)

# initializing turtle (t)
t = turtle.Turtle(shape="turtle")
t.shapesize(2,2,2)
t.color("black", "green")
t.speed(3)
t.left(randint(120,180))

# ---While loop--- 
collisions = 0
while collisions <= 25:
    t.forward(3)
    if t.xcor() <= -200 or t.xcor() > 200 or t.ycor() <= -200 or t.ycor() >= 200: 
        t.forward(-3)
        t.left(randint(90,179))
        collisions += 1
s.exitonclick()
