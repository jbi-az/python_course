import turtle

# initialize screen (s)
s = turtle.Screen()
s.setup(width=1.0, height=1.0, startx=10, starty=0)
s.bgcolor("#d3d3d3")

# title 
text = turtle.Turtle()
text.penup()
text.hideturtle()
text.goto(0,300)
text.write("Title", align="center", font=("Arial",24,"bold")) 


s.exitonclick()
