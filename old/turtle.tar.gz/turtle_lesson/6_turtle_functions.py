import turtle

# initialize screen (s)
s = turtle.Screen()
s.setup(width=1.0, height=1.0, startx=10, starty=0)
s.bgcolor("#d3d3d3")

# title 
text = turtle.Turtle()
text.penup()
text.hideturtle()
text.goto(0,300)
text.write("Drawing squares (spiral)", align="center", font=("Arial",24,"bold")) 

# initialize turtle
t = turtle.Turtle(visible=False)
t.speed(0)
t.color("black", "green")

# ---function to draw colored squares with--- # 
def draw_square(size):
    t.penup()
    t.goto(-size/2,size/2)
    t.pendown()
   
    for i in range(4):
        t.forward(size)
        t.right(90)

# ---Call to function with a for loop--- # 
for i in range(60):
    draw_square(i * 3)
    t.right(5)

s.exitonclick()
