import turtle

# initialize screen (s)
s = turtle.Screen()
s.setup(width=1.0, height=1.0, startx=10, starty=0)
s.bgcolor("#d3d3d3")

# title 
text = turtle.Turtle(visible=False)
text.penup()
text.goto(0,200)
text.write("For loop (square)", align="center", font=("Arial",24,"bold")) 

# initialize turtle
t = turtle.Turtle(shape="turtle", visible=False)
t.shapesize(2,2,2)
t.color("black", "green")
t.speed(1)

# ---Using a for loop to draw a square--- #

# set turtle on top-left corner
t.penup()
t.goto(-100,100)
t.pendown()
t.showturtle()

# ---For loop--- #
for i in range(4):
    t.forward(200)
    t.right(90)

s.exitonclick()
