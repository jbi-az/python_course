import turtle

# initialize screen (s)
s = turtle.Screen()
s.setup(width=1.0, height=1.0, startx=10, starty=0)
s.bgcolor("#d3d3d3")

# title 
text = turtle.Turtle()
text.penup()
text.hideturtle()
text.goto(0,300)
text.write("Project: squaring the circles", align="center", font=("Arial",24,"bold")) 

# ---function to draw squares with--- # 
def draw_square(size):
    t = turtle.Turtle(visible=False)
    t.penup()
    t.goto(-size/2,size/2)
    t.pendown()
   
    for i in range(4):
        t.forward(size)
        t.right(90)

# ---Function to draw lines according to the excercise---  
def draw_lines(cx, cy, parts):
    t = turtle.Turtle(visible=False)
    t.speed(2)
    n = 1
    while n <= parts:
        t.penup()
        t.goto(0+(n-1)*(cx/parts),cy)
        t.pendown()
        t.goto(cx,cy-n*(cy/parts))
        n += 1

def squaring_the_circle(size,parts):
    draw_square(size)
    draw_lines(-size/2,size/2,parts)     #Q1
    draw_lines(size/2,size/2,parts)      #Q2
    draw_lines(size/2,-size/2,parts)     #Q3
    draw_lines(-size/2,-size/2,parts)    #Q4

squaring_the_circle(500,5)

s.exitonclick()

