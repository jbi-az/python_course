import turtle

# initialize screen (s)
s = turtle.Screen()
s.setup(width=1.0, height=1.0, startx=10, starty=0)
s.bgcolor("#d3d3d3")

# title 
text = turtle.Turtle()
text.penup()
text.hideturtle()
text.goto(0,300)
text.write("Drawing multiple colored squares", align="center", font=("Arial",24,"bold")) 

# initialize turtle
t = turtle.Turtle()
t.speed(6)
t.color("black", "green")

# ---function to draw colored squares with--- # 
def draw_square(size,color):
    t.hideturtle()
    t.penup()
    t.goto(-size/2,size/2)
    t.pencolor(color)
    t.pendown()
    t.pensize(4)
   
    for i in range(4):
        t.forward(size)
        t.right(90)

colors=["red", "orange", "yellow", "green", "blue"]

# ---Call to function with a for loop--- # 
for i in range(6):
    draw_square(i * 100, colors[i-1])

s.exitonclick()
